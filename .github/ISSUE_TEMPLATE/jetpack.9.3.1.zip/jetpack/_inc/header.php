<?php $current = $_GET['page']; ?>

