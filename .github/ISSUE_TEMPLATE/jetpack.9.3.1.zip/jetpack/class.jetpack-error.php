<?php
/**
 * Class Jetpack_Error
 *
 * This is deprecated.
 */
class Jetpack_Error extends WP_Error {}
